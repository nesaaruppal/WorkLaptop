# Kivy4

This package allows you to create Kivy projects faster\
with a pre-made kivy template.